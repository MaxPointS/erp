<?php

namespace App\Http\Controllers\cpanel;

use App\Http\Controllers\Controller;
use App\Models\company;
use App\Models\companyservicetype;
use App\Models\service;
use Illuminate\Validation\Rules\File;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

use Illuminate\Support\Str;
use Illuminate\View\View;


class companyController extends Controller
{
    //
    public function viewList() //:View
    {
        $companies = company::with("companyservicetype")->with("services")->get();
        $services = service::get();
        // return  $companies;
        $pageName = "Companies";
        // $companyservicetype = companyservicetype::get();
        return view('cpanel.pages.companiesservice', compact("pageName", "companies","services"));
    }
    public function create(): View
    {
        $pageName = "->Companies->Create";
        $companyservicetype = companyservicetype::get();
        return view('cpanel.pages.CreateCompany', compact("pageName", "companyservicetype"));
    }
    public function store(Request $request) ///:RedirectResponse
    {
        $validation = $request->validate([
            "name" => "required",
            "image" => [File::image(), File::types(['jpeg', 'png', "jpg"])],
            "arname" => "required",
            "address" => "required",
            "companyServiceType" => "required",
            "location" => "required",
            "tel" => "required",
            "araddress" => "required"

        ]);
        $newfilepath = '';

        if ($request->has("image")) {
            $extension = $request->image->extension();
            $filename = hash("Sha256", time());
            $newfilepath =   $filename . "." .   $extension;
            $request->image->move(public_path("images"), "/" . $newfilepath);
        }

        $company = company::firstOrNew([
            "uuid" => Str::uuid(),
            "name" => $request->name,
            "arname" => $request->arname,
            "address" => $request->address,
            "araddress" => $request->araddress,
            "image" => $newfilepath,
            "tel" => $request->tel,
            "location" => $request->location,
            "active" => $request->has("status") ? true : false,
            "companyservicetype_id" => $request->companyServiceType,
            "created_at" => now(),
            "updated_at" => now(),
        ]);

        $company->save();
        return redirect()->route('showCompaniesList');
    }

    public function AddService(): View
    {
        $companies = company::get();

        return view('cpanel.pages.addCompanyService', compact("companies"));
    }

    public function storeService(Request $request)
    {
        $validation = $request->validate([
            "company" => "required",
            "image" => [File::image(), File::types(['jpeg', 'png', "jpg"])],
            "arname" => "required",
            "name" => "required",
            "ardescription" => "required",
            "description" => "required",
            "priceBefore" => ["required"],
            "price" =>["required"],
        ]);
        $newfilepath = '';

        if ($request->has("image")) {
            $extension = $request->image->extension();
            $filename = hash("Sha256", time());
            $newfilepath =   $filename . "." .   $extension;
            $request->image->move(public_path("images"), "/" . $newfilepath);
        }


        $service = service::firstOrNew([
            "uuid"=>Str::uuid(),
            "company_id" => $request->company,
            "image" =>$newfilepath,
            "arname" =>  $request->arname,
            "name" => $request->name,
            "ardescription" =>  $request->ardescription,
            "description" => $request->description,
            "priceBefore" =>  $request->priceBefore,
            "price" => $request->price,
        ]);

        $service->save();
        return redirect()->route('showCompaniesList');
    }
}
