<?php

namespace App\Http\Controllers\front;

use App\Http\Controllers\Controller;
use App\Models\cart;
use App\Models\company;
use App\Models\governArea;
use App\Models\service;
use Illuminate\View\View;
use Illuminate\Http\Request;

class companyController extends Controller
{
    //

    public function home() //:View
    {
        $subtotalAmount = 0.0;
        // $totalCartAmount = 0.0;

        $cart = cart::where("token", "=", session()->get("tokenCart"))->get();
        foreach ($cart  as $key => $value) {
            $subtotalAmount += round($value->totalprice, 3);
        }
        return view('front.pages.index', compact("cart", "subtotalAmount"));
    }

    public function viewList() //:View
    {
        $companiesWithServices = company::with("services")->with("companyservicetype")->get();
        // return $companiesWithServices;
        $cart = cart::where("token", "=", session()->get("tokenCart"))->get();
        $subtotalAmount = 0.0;

        foreach ($cart  as $key => $value) {
            $subtotalAmount += round($value->totalprice, 3);
        }
        return view('front.pages.Menu', compact("companiesWithServices", "cart", "subtotalAmount")); //->with(["subtotalAmount"=>$subtotalAmount]);
    }

    public function decreaseCartQty(Request $request) //:View
    {
        // return $request ;
        $cart = cart::where(["service_id" => $request->proid])->with("services")->get();
        //return $cart ->first()->services->first()->price;
        // return $request;
        foreach ($cart as $key => $item) {
            # code...
            $item->qty  = $item->qty  - 1;
            $item->totalprice = $item->services->first()->price * $item->qty;

            $item->save();
        }
        // $cart = cart::where(["service_id"=>$id])->with("services")->get();

        return $cart;
    }

    public function increaseCartQty(Request $request) //:View
    {
        // return $request ;
        $cart = cart::where(["service_id" => $request->proid])->with("services")->get();
        //return $cart ->first()->services->first()->price;
        // return $request;
        foreach ($cart as $key => $item) {
            # code...
            $item->qty  = $item->qty  +1;
            $item->totalprice = $item->services->first()->price * $item->qty;

            $item->save();
        }
        // $cart = cart::where(["service_id"=>$id])->with("services")->get();

        return $cart;
    }

    public function destroy(Request $request,$id) //:View
    {
 
        $cart = cart::where(["service_id" => $request->proid])->get();
 
        // return $request;
        foreach ($cart as $key => $item) {
            # code...
            $item->delete();
        }
        // $cart = cart::where(["service_id"=>$id])->with("services")->get();

        if($cart->count()==0)
            return response()->json(["0"]);

        return $cart;
    }

    public function fillCart(Request $request) //:View
    {
        // return $request;
        if (!session()->has("tokenCart"))
            session()->put("tokenCart", $request->_token);

        $Existcart = cart::where(["token" => $request->_token])->with("services")->get();

        if ($Existcart->count() == 0) {

            $cart = cart::create([
                "token" => $request->_token,
                "service_id" => $request->ServiceID,
                "qty" => $request->ServiceQty,
                "TotalPrice" => $request->ServiceQty * $request->price,

            ]);
            $cart->save();

            $cartTable = array(array());
            array_push($cartTable[0], $cart);
            return   response()->json($cartTable);

            // return response()->json([
            //     "CartorTable" => [
            //         [
            //             "Price" => $request->ServiceQty * $request->price,
            //             "Qty" => $request->ServiceQty,
            //             "uuid" => $request->ServiceID,
            //             "TotalPrice" => round($request->ServiceQty * $request->price, 3,),
            //             "ProductName" =>  $cart->services->first()->name,
            //         ],

            //     ],
            //     "CartLenth" => 1,
            //     "CartTotalPrice"=>round($request->ServiceQty * $request->price, 3),

            // ]);
        } else {
            $Existcart = cart::where(["token" => $request->_token, "service_id" => $request->ServiceID])->with("services")->get();


            foreach ($Existcart as $key => $item) {
                # code...
                $item->token = $request->_token;
                $item->service_id = $request->ServiceID;
                $item->qty = $request->ServiceQty;
                $item->totalprice = $request->ServiceQty * $request->price;
                $item->save();
            }

            $cartTable = array(array());
            array_push($cartTable[0], $Existcart);
            // array_push($cartArrayBack["CartorTable"], $Existcart);

            return   response()->json($Existcart);
            // return response()->json([
            //     "CartorTable" => [
            //         [
            //             "Price" => $request->price,
            //             "Qty" => $request->ServiceQty,
            //             "uuid" => $request->ServiceID,
            //             "totalprice" => round($request->ServiceQty * $request->price, 3),
            //             "ProductName" =>$Existcart->first()->services->first()->name,
            //             "CartLenth" => $Existcart->count()
            //         ],
            //     ],
            //     "CartLenth" => 1,
            //     "CartTotalPrice"=>round($request->ServiceQty * $request->price, 3),
            // ]);
        }
    }


    public function getCustomerDetails()//:View
    {
        $areas = governArea::all();
        $cart = cart::with("services")->where("token","=",session()->get("tokenCart"))->get();
// return $cart; 
        return view("front.pages.cartOrders",compact("cart","areas"));
    }
}
