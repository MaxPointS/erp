<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class service extends Model
{
    use HasFactory;

   protected $fillable = [
        "uuid",
        // "company" => $request->company,
        "company_id",
        "image" ,
        "arname" ,
        "name" ,
        "ardescription" ,
        "description" ,
        "priceBefore",
        "price",
   ];
    // protected $primaryKey = "uuid";

    public function  company():BelongsTo{
        return $this->belongsTo(company::class,"company_id","uuid");
    }

    public function  cart():BelongsToMany{
        return $this->BelongsToMany(cart::class);
    }
}
