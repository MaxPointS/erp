<!DOCTYPE html>
<html <?php if(App::islocale("ar") ): ?> lang="ar" dir="rtl" <?php else: ?> lang="en" dir="ltr" <?php endif; ?>>
<head>
 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> Dashboard  -  CompanyName </title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport" >

    <?php echo $__env->make('cpanel.inc.Css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini" <?php if(App::islocale("ar") ): ?> dir="rtl" <?php else: ?> dir="ltr" <?php endif; ?> >
    <!-- Site wrapper -->
    <div class="wrapper">

        <!----------------------------------------header with nav---------------------------->
    
        <?php echo $__env->make('cpanel.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- =============================================== -->
        <!-- Left side column. contains the sidebar -->
        <!------------------------------------------------------------------Left side--------------------------------------->
 
        <?php echo $__env->make('cpanel.inc.SideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
        <!-- =============================================== -->
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">

            <section class="content-header">
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                    <?php echo $__env->yieldContent('content-header'); ?>
                  </ol>
            
            </section>


        
            <br/>
            <!-- Main content -->
            <section class="content">
              
                <?php echo $__env->yieldContent('content'); ?>
                
           

              
                
                
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->


        <!-------------------------------------------footer---------------------------------------------------->
       
        <?php echo $__env->make('cpanel.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <!-- Control Sidebar -->
        <!-------------------------------------------controlslid---------------------------------------------------->
        <?php echo $__env->make('cpanel.inc.controlside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /.control-sidebar -->
        
        
        
        
        
       
        <div class="control-sidebar-bg"></div>
    </div>
    <!-- ./wrapper -->
    <!-----------------------------------------------------------------------scripts------->
   
    <?php echo $__env->make('cpanel.inc.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <?php echo $__env->yieldContent('scriptes'); ?>



    
</body>
</html>



<?php /**PATH C:\xampp\htdocs\ERPI\resources\views/cpanel/layout/master.blade.php ENDPATH**/ ?>