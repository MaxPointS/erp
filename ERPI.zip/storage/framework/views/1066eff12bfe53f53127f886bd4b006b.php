


<?php $__env->startSection('services'); ?>
    <!-- Section - Menu -->
    


    <section class="section header-mt-10 section-main section-main-1 bg-dark">
        <div class="container dark col-md-12 " style="padding:0px !important">
            <div class="slide-container">

                <div class="bg-image zooming">
                    <img src="<?php echo e(asset('/images/backg.jpeg')); ?>" alt="">
                </div>
                <h2 class="hide-sm">&nbsp;&nbsp;&nbsp;</h2>
                <div class="content dark">
                    <div id="section-main-1-carousel-content">
                        <div class="content-inner">
                            
                            <div class="form-group">
                                <a href="<?php echo e(route('companyServices')); ?>"
                                    class="btn btn-success btn-block btn-sm btn-submit">
                                    <span class="description"><?php echo e(trans('frontHeader.enterPage')); ?></span><i
                                        class="fa <?php if(App::isLocale('en')): ?> fa-arrow-right <?php else: ?> fa-arrow-left <?php endif; ?>"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>




    

    <br />
    <section class="section pb-0 protrude" style="display:none;">
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ERPI\resources\views/front/pages/index.blade.php ENDPATH**/ ?>