<script src="<?php echo e(asset('dist/js2/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/tether.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/jquery.appear.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/jquery.scrollTo.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/jquery.localScroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/jquery.mb.YTPlayer.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/twitterFetcher_min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/skrollr.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/animsition.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/timepicker.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/jquery.datetimepicker.full.min.js')); ?>"></script>

<!-- JS Core -->
<script src="<?php echo e(asset('dist/js2/core.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/custom.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/formValidation.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/validation.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/my_account.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js2/cartactions.js')); ?>"></script>




<script>
    $(document).ready(function() {
        let submitFormLink = document.getElementById('submitFormLink');
        $("#submitFormLink").click(function(e) {
            e.preventDefault();
            $('#changeLangForm').submit();
        });
    });
</script>


<?php /**PATH C:\xampp\htdocs\ERPI\resources\views/front/inc/frontScripts.blade.php ENDPATH**/ ?>