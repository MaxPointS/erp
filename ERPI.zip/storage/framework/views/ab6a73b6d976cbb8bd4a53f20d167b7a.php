<?php $__env->startSection('content-header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br />

    <div class="row ">

        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="box box-widget widget-user-2">
                    <!-- Add the bg color to the header using any of the bg-* classes -->
                    <div class="widget-user-header bg-yellow">
                        <div class="widget-user-image">
                            <img class="img-circle" src="<?php echo e(asset('images') . '/' . $company->image); ?>" alt="User Avatar">
                        </div>
                        <!-- /.widget-user-image -->
                        <h3 class="widget-user-username">
                            <?php if(App::islocale('ar')): ?>
                                <?php echo e($company->arname); ?>

                            <?php else: ?>
                                <?php echo e($company->name); ?>

                            <?php endif; ?>

                        </h3>
                        <h5 class="widget-user-desc">
                            <?php if(App::islocale('ar')): ?>
                                <?php echo e($company->companyservicetype->arname); ?>

                            <?php else: ?>
                                <?php echo e($company->companyservicetype->name); ?>

                            <?php endif; ?>
                        </h5>
                    </div>
                    <div class="box-footer no-padding pull-end">
                        <ul class="nav nav-stacked">
                            <li><a href="#">Projects <span
                                        class=" <?php if(App::islocale('ar')): ?> pull-left  <?php else: ?> pull-right <?php endif; ?>  badge bg-blue">31</span></a>
                            </li>
                            <li><a href="#">Tasks <span
                                        class="<?php if(App::islocale('ar')): ?> pull-left  <?php else: ?> pull-right <?php endif; ?>  badge bg-aqua">5</span></a>
                            </li>
                            <li><a href="#">Completed Projects <span
                                        class="<?php if(App::islocale('ar')): ?> pull-left  <?php else: ?> pull-right <?php endif; ?>   badge bg-green">12</span></a>
                            </li>
                            <li><a href="#">Followers <span
                                        class="<?php if(App::islocale('ar')): ?> pull-left  <?php else: ?> pull-right <?php endif; ?>   badge bg-red">842</span></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
    <div class="row ">
        <div class="col-md-12 ">
            <div class="box" style="border: 0 !important;box-shadow: 0 1px 9px 3px rgba(0,0,0,0.1);">
                <div class="box-header">
                    <h3 class="box-title">Filtering </h3>
                </div>
                <div class="box-body ">
                    <div class="form-row">
                        <div class="table-responsitve">
                            <table id="services" class="table">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <img src="<?php echo e(asset('images') . '/' . $service->Image); ?>"
                                                    style="width: 70px;height: 70px;" alt="">
                                            </td>
                                            <td>
                                                <?php if(App::islocale('ar')): ?>
                                                    <?php echo e($service->arname); ?>

                                                <?php else: ?>
                                                    <?php echo e($service->name); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if(App::islocale('ar')): ?>
                                                    <?php echo e($service->ardescription); ?>

                                                <?php else: ?>
                                                    <?php echo e($service->description); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($service->priceBefore); ?>

                                            </td>
                                            <td>
                                                <?php echo e($service->price); ?>

                                            </td>
                                            <td>
                                                <?php if($service->status): ?>
                                                    <span class="label label-success">
                                                        <?php echo e(trans('addServiceTrans.active')); ?>

                                                    </span>
                                                <?php else: ?>
                                                    <span class="label label-danger">
                                                        <?php echo e(trans('addServiceTrans.notactive')); ?>


                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->



        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scriptes'); ?>
    <script src=" <?php echo e(asset('plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
    <script>
        //Date picker
        $('.datepicker').datepicker({
            autoclose: true
        });
        $("#TableVichleInsurance").dataTable({
            info: false,
            // ordering: true,
            paging: true
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cpanel.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ERPI\resources\views/cpanel/pages/companiesservice.blade.php ENDPATH**/ ?>