<style>
    /* Set the size of the div element that contains the map */
    #googleMap,
    #googleMap2 {
        height: 150px;
        /* The height is 400 pixels */
        width: 100%;
        /* The width is the width of the web page */
    }
</style>
<!-- Footer -->
<footer id="footer" class="bg-dark dark">

    <div class="container">
        <!-- Footer 1st Row -->
        <!-- <div class="footer-first-row row">
          <div class="col-lg-3 text-center">
              <a href="http://alkadisweets.com/"><img src="http://alkadisweets.com/assets/img/hesabe.png" alt="" width="258" class="mt-2 mb-5"></a>
          </div>
          <div class="col-lg-3">
              <h5 class="title footer-subtitle mb-0">فرع العارضيه</h5>
              <ul class="list-posts">
                  <li>
                      <span class="date footer-sub-sub-title">شارع محمد نزال المعصب، العارضية، الكويت</span>
                  </li>
                  <li>
                      <div>
                          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3479.4737003447217!2d47.91299831509765!3d29.297777382160024!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3fcf095727f3b641%3A0xbe69d77e8feb4272!2sAlkadi%20sweetz!5e0!3m2!1sen!2sin!4v1566898794504!5m2!1sen!2sin"
                              width="100%" height="220" frameborder="0" style="border:0" allowfullscreen></iframe>
                      </div>
                  </li>
              </ul>
          </div>
          <div class="col-lg-3">
              <h5 class="title footer-subtitle mb-0">فرع المهبوله</h5>
              <ul class="list-posts">
                  <li>
                      <span class="date footer-sub-sub-title">سالم الصبا، الكويت</span>
                  </li>
                  <li>
                      <div>
                          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3484.218663370137!2d48.11920111509461!3d29.15822798221337!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3fcf090ac0f7323b%3A0x3c088b132162f670!2z2K3ZhNmI2YrYp9iqINin2YTZg9in2K_ZiiBBbCBLYWRpIFN3ZWV0cw!5e0!3m2!1sen!2sin!4v1566898995234!5m2!1sen!2sin"
                              width="100%" height="220" frameborder="0" style="border:0" allowfullscreen></iframe>
                      </div>
                  </li>
              </ul>
          </div>
          <div class="col-lg-3">
              <h5 class="title footer-subtitle mb-5">معلومات</h5>
              <ul class="list-posts">
                  <li>
                      <span class="title">ساعات العمل:</span>
                      <span class="date">من 7:00 صباحًا إلى 11:00 مساءً</span>
                  </li>
                  <li>
                      <span class="title">دعم العملاء</span>
                      <span class="date">24573554 </span>
                  </li>
                  <li>
                      <span class="title">البريد الإلكتروني</span>
                      <span class="date">contact@alkadi.com</span>
                  </li>
                  <li>
                      <a href="https://api.whatsapp.com/send?phone=96566095323" target="_blank" class="icon icon-social icon-circle icon-sm icon-facebook"><i class="fa fa-whatsapp"></i></a>
                      <a href="https://www.instagram.com/alkadisweetz" target="_blank" class="icon icon-social icon-circle icon-sm icon-instagram"><i class="fa fa-instagram"></i></a>
                  </li>
              </ul>
          </div>
      </div> -->
        <!-- Footer 2nd Row -->
        <div class="footer-second-row text-center">
            <span class="text-muted"> <a href="https://ebaakw.com/" target="_blank"> <i class="ti ti-world"></i> Powered
                    By EBAA </a> </span>
        </div>
    </div>

    <!-- Back To Top -->
    <a href="#" id="back-to-top"><i class="ti ti-angle-up"></i></a>

</footer>
<!-- Footer / End -->
<!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAZ9PnNW3s3rDPRr50Te5mpmsvtf6rNDZo"></script>
<script>
    var myCenter = new google.maps.LatLng(51.059955, -114.211807);
    var myCenter2 = new google.maps.LatLng(50.9156772, -113.9640719);

    function initialize() {
        var mapProp = {
            center: myCenter,
            zoom: 14,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
        var marker = new google.maps.Marker({
            position: myCenter,
            animation: google.maps.Animation.DROP,
            icon: 'http://www.fergusandbix.com/images/FB-pin.png'
        });
        marker.setMap(map);

        var mapProp2 = {
            center: myCenter2,
            zoom: 14,
            mapTypeId: google.maps.MapTypeId.ROADMAP2
        };
        var map = new google.maps.Map(document.getElementById("googleMap2"), mapProp2);
        var marker = new google.maps.Marker({
            position: myCenter2,
            animation: google.maps.Animation.DROP,
            icon: 'http://www.fergusandbix.com/images/FB-pin.png'
        });
        marker.setMap(map);
    }
    google.maps.event.addDomListener(window, 'load', initialize);
</script> -->

</div>

<!-- Panel Cart -->

<!-- Panel Mobile -->
<nav id="panel-mobile">
    <div class="module module-logo bg-light light">
        <a href="">
            <img src="<?php echo e(asset('imgs/logo1.png')); ?>" alt="" width="128">
        </a>
        <button class="close" data-toggle="panel-mobile"><i class="fa fa-close"></i></button>
    </div>


    <nav class="module module-navigation">

    </nav>

    <div class="module module-social">
        <h6 class="text-sm mb-3">تابعنا!</h6>
        <a href=""
            target="_blank" class="icon icon-social icon-circle icon-sm icon-facebook"><i
                class="fa fa-facebook"></i></a>
        <a href="" target="_blank"
            class="icon icon-social icon-circle icon-sm icon-instagram"><i class="fa fa-instagram"></i></a>
        <a href="" target="_blank"
            class="icon icon-social icon-circle icon-sm icon-instagram"><i class="fa fa-twitter"></i></a>
    </div>
</nav>

<!-- Body Overlay -->
<div id="body-overlay"></div>
</div>



<div id="toast-container" style="display: none;" class="toast-bottom-right">
    <div class="toast toast-success" aria-live="polite" style="">
        <div class="toast-message">تم إضافة الاصناف إلى سلة المشتريات</div>
    </div>
</div>








<div id="panel-cart" class="">
    <div class="panel-cart-container">
        <div class="panel-cart-title">
            <h5 class="title"><?php echo e(trans('frontFooter.cart')); ?></h5>
            <button class="close" data-toggle="panel-cart"><i class="fa fa-close"></i></button>
        </div>
        <div class="panel-cart-content text-md">

            
            <table class="table-cart ">
                <tbody id="CartTableBody">
                    <?php $sum = 0; ?>
                    <?php if($cart->count() > 0): ?>
                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="cart-qty">
                                    <div class="row text-md">
                                        <span onclick="RemoveQtyFromCart(this)" uuid="<?php echo e($item->service_id); ?>"
                                            productqty="<?php echo e($item->qty); ?>" productPrice="<?php echo e($item->totalprice); ?>"
                                            producttotalprice="<?php echo e(round($item->totalprice * $item->qty,3 )); ?>"
                                            class="remove_item order-qty-btn sub-qty"><i
                                                class="fa fa-minus-circle"></i></span>

                                        &nbsp;&nbsp;
                                        <strong class="order-item-qty"
                                            id="Qty_Pro_<?php echo e($item->service_id); ?>"><?php echo e($item->qty); ?></strong>
                                        &nbsp;&nbsp;

                                        <span onclick="AddQtyToCart(this)" uuid="<?php echo e($item->service_id); ?>"
                                            productqty="<?php echo e($item->qty); ?>" productPrice="<?php echo e($item->totalprice); ?>"
                                            producttotalprice="<?php echo e(round($item->totalprice * $item->qty,3 )); ?>"
                                            class="remove_item order-qty-btn add-qty"><i
                                                class="fa fa-plus-circle"></i></span>

                                        


                                    </div>
                                </td>
                                <td class="title">
                                    <span class="name"><a href="#">
                                    <?php if(App::islocale('ar')): ?>
                                        <?php echo e($item->services->first()->arname); ?>

                                    <?php else: ?>
                                    <?php echo e($item->services->first()->name); ?>

                                        
                                    <?php endif; ?>
                                        
                                    </a></span>
                                </td>
                                <td class="price">
                                    <span
                                        id="TotalPrice_Pro_<?php echo e($item ->service_id); ?>"><?php echo e(round($item->services->first()->price * $item->qty,3 )); ?>

                                    </span>
                                </td>
                                <td class="actions">
                                    <a href="#" onclick="DeleteFromCart(this)"
                                        uuid="<?php echo e($item->service_id); ?>" productqty="<?php echo e($item->qty); ?>"
                                        productPrice="<?php echo e($item->services->first()->price); ?>"
                                        producttotalprice="<?php echo e($item->totalprice); ?>"
                                        class="action-icon btn-remove text-danger" ><i class="ti ti-close"></i></a>
                                        
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>

            </table>
            <div class="cart-summary <?php if($cart->count()==0): ?> d-none <?php endif; ?>" id="cart-summaryEmpty">
                <div class="row">
                    <div class="col-7 text-right text-muted"><?php echo e(trans('frontHeader.Amount') . ' :'); ?>

                    </div>
                    <div class="col-5"><strong id="cartsubTotal">
                            
                            <?php echo e($subtotalAmount); ?>

                        </strong></div>
                </div>
                <div class="row">
                    <div class="col-7 text-right text-muted"><?php echo e(trans('frontHeader.delvCost') . ' :'); ?>

                    </div>
                    <div class="col-5"><strong id="cartDelv"><?php echo e(session()->get('DelvCost')); ?></strong></div>
                </div>
                <hr class="hr-sm">
                <div class="row text-lg">
                    <div class="col-7 text-right text-muted"><?php echo e(trans('frontHeader.TotalPrice') . ' :'); ?>

                    </div>
                    <div class="col-5"><strong id="cart_total">
                        <?php echo e($subtotalAmount); ?>


                            
                            

                        </strong>
                    </div>
                </div>
                <hr class="mb-3">
                <div class="row ">
                    <!-- <div class="col-12">General Note</div> -->
                    <div class="col-12">
                        <textarea cols="30" name="Commets" id="modal-comment-textarea" rows="2" class="form-control"
                            placeholder="<?php echo e(trans('frontHeader.Comments') . '(' . trans('frontHeader.optionalField') . ')'); ?>"></textarea>
                    </div>
                </div>
            </div>
            
            <div class="page-content <?php if($cart->count()>0): ?> d-none <?php endif; ?> " id="CartEmpty">
                <p class="text-center"><?php echo e(trans('frontFooter.emptyCart')); ?></p>
            </div>
            
        </div>
    </div>


    <div class="panel-cart-action">
        
        <div style="width:42%;float:right" class="text-center">
            <a href="<?php echo e(url('/Registration-Login')); ?>" id="go-to-checkout"
                class="btn btn-outline-secondary text-center btn-md">
                
                <span><?php echo e(trans('frontFooter.customerLogin')); ?></span>
            </a>
        </div>
        <div style="width:8%;float:right" class="text-center">OR</div>

        <div style="width:42%;float:right" class="text-center">
            <a href="<?php echo e(route('customerCart')); ?>" id="go-to-checkout" class="btn btn-secondary text-center btn-md">
                <span><?php echo e(trans('frontFooter.submitService')); ?></span>
            </a>
        </div>
    </div>
</div>










<!-- -------------------------------------------------------------------------------------------------------------------------------------------- -->





<!-- Modal / Login -->











<?php /**PATH C:\xampp\htdocs\ERPI\resources\views/front/inc/footer.blade.php ENDPATH**/ ?>