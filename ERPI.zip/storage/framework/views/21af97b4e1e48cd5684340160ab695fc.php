


<?php $__env->startSection('css'); ?>
    <style>
        .select2-selection {
            border-radius: 0 !important;
        }
    </style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('storeService')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row ">
            <div class="col-md-12 ">
                <div class="box" style="border: 0 !important;box-shadow: 0 1px 9px 3px rgba(0,0,0,0.1);">
                    <div class="box-header">
                        <h3 class="box-title">
                            <?php echo e(trans('addServiceTrans.title')); ?>

                        </h3>
                    </div>
                    <div class="box-body ">

                        <div class="form-row">

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="datePolicy">
                                        <?php echo e(trans('addServiceTrans.clientcompany')); ?>

                                    </label>

                                    <div class="input-group text">
                                        <div class="input-group-addon">
                                            <i class="fa fa-building-o"></i>
                                        </div>
                                        
                                        <select class="form-control select2 " style="border-radius:0 !important; " value="<?php echo e(old('company')); ?>"
                                            name="company" id="company">
                                            <option value="">
                                                <?php echo e(trans('addServiceTrans.choose')); ?>

                                            </option>
                                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(App::islocale('ar')): ?>
                                                    <option value="<?php echo e($company->uuid); ?>"><?php echo e($company->arname); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($company->uuid); ?>"><?php echo e($company->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                    <label style="color: red">
                                        <?php $__errorArgs = ['company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                    <!-- /.input group -->
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>
                                        <?php echo e(trans('addServiceTrans.arname')); ?>


                                    </label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="">Ar</i>
                                        </div>
                                        <input type="text" name="arname" id="arname" value="<?php echo e(old('arname')); ?>"
                                            class="form-control pull-right datepicker">
                                    </div>
                                    <!-- /.input group -->
                                    <label style="color: red">
                                        <?php $__errorArgs = ['arname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>
                                        <?php echo e(trans('addServiceTrans.name')); ?>


                                    </label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="">En</i>
                                        </div>
                                        <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>"
                                            class="form-control pull-right ">
                                    </div>
                                    <!-- /.input group -->
                                    <label style="color: red">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>
                                        <?php echo e(trans('addServiceTrans.ardescription')); ?>

                                    </label>

                                    <div class="input-group date">
                                        
                                        <textarea class="form-control" name="ardescription" id ="ardescription" style="resize: none" cols="100"
                                            rows="5" autocomplete="off"><?php echo e(old('ardescription')); ?></textarea>
                                    </div>
                                    <label for="" style="color: red">
                                        <?php $__errorArgs = ['ardescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                    <!-- /.input group -->
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>
                                        <?php echo e(trans('addServiceTrans.description')); ?>


                                    </label>

                                    <div class="input-group date">
                                        
                                        <textarea class="form-control"  style="resize: none"  name="description" id ="description" cols="100" rows="5"
                                            autocomplete="off"><?php echo e(old('description')); ?></textarea>
                                    </div>
                                    <label for="" style="color: red">
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                    <!-- /.input group -->
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>
                                        <?php echo e(trans('addServiceTrans.price')); ?>

                                    </label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-dollar"></i>
                                        </div>
                                        <input type="number" min="0.000" name="priceBefore" id="priceBefore" value="<?php echo e(old('priceBefore')); ?>"
                                            minlength="0.000" step="0.001" placeholder="0.000" class="form-control pull-right ">
                                    </div>
                                    <label for="" style="color: red">
                                        <?php $__errorArgs = ['priceBefore'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                    <!-- /.input group -->
                                </div>
                            </div>


                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>
                                        <?php echo e(trans('addServiceTrans.sellprice')); ?>


                                    </label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-dollar"></i>
                                        </div>
                                        <input type="number"min="0.000" name="price" id="price" step="0.001" value="<?php echo e(old('price')); ?>" minlength="1.000"
                                            placeholder="0.000" class="form-control pull-right ">
                                    </div>
                                    <label for="" style="color: red">
                                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                    <!-- /.input group -->
                                </div>
                            </div>



                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>
                                        <?php echo e(trans('addServiceTrans.status')); ?>

                                    </label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-picture-o"></i>
                                        </div>
                                        <input type="file" class="form-control pull-right "  name="image" value="<?php echo e(old('image')); ?>"
                                            id="image" accept=".jpg, .png, .jpeg">
                                    </div>
                                    <!-- /.input group -->
                                    <label for="" style="color: red">
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                            </div>


                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>
                                        <?php echo e(trans('addServiceTrans.status')); ?>

                                    </label>
                                    <div class="form-group">

                                        <div class="">
                                            <label>
                                                <input  checked name="status"  type="checkbox" data-toggle="toggle"
                                                    data-style="slow">
                                            </label>
                                        </div>
                                    </div>
                                    <!-- /.input group -->
                                </div>
                            </div>



                        </div>


                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <button class="btn btn-success pull-right">filter</button>
                    </div>
                </div>
                <!-- /.box -->



            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scriptes'); ?>
    <script>
        $(".select2").select2();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cpanel.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ERPI\resources\views/cpanel/pages/addCompanyService.blade.php ENDPATH**/ ?>