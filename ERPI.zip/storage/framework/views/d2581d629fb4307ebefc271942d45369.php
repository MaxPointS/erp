<?php $__env->startSection('content-header'); ?>
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <?php if(App::islocale('ar')): ?>
        <style>
            #ableAreas_filter,
            .dataTables_filter,
            .dataTables_paginate {
                float: left;
                text-align: end;
            }
        </style>
    <?php endif; ?>

    <style>
        .select2-selection {
            border-radius: 0 !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br />



    <div class="row ">

        <?php $__currentLoopData = $governs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $govern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="info-box bg-<?php echo e($govern->color); ?>">
                    <span class="info-box-icon"><i class="fa fa-bookmark-o"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">
                            <?php if(App::islocale('ar')): ?>
                                <?php echo e($govern->arname); ?>

                            <?php else: ?>
                                <?php echo e($govern->name); ?>

                            <?php endif; ?>
                        </span>
                        <span class="info-box-number"><?php echo e($govern->govern_areas->count()); ?></span>

                        <div class="progress">
                            <div class="progress-bar"
                                style="width:   <?php echo e(round($govern->govern_areas->count() / $total, 2) * 100); ?>%"></div>
                        </div>
                        <span class="progress-description">
                            <?php echo e(round($govern->govern_areas->count() / $total, 3) * 100); ?> % of total
                        </span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>

    <div class="row ">
        <div class="col-md-12 ">
            <div class="box" style="border: 0 !important;box-shadow: 0 1px 9px 3px rgba(0,0,0,0.1);">
                <div class="box-header">
                    <h3 class="box-title"><?php echo e(trans('areasTrans.CreateAreaTitle')); ?> </h3>
                </div>
                <div class="box-body ">
                    <div class="form-row">

                        <div class="col-md-6">

                            <button data-toggle="modal" data-target="#AddNewArea" class="btn btn-success"><?php echo e(trans('areasTrans.CreateArea')); ?> </button>
                        </div>



                    </div>

                </div>
                <!-- /.box -->



            </div>
        </div>
    </div>




        <div class="row ">
            <div class="col-md-12 ">
                <div class="box" style="border: 0 !important;box-shadow: 0 1px 9px 3px rgba(0,0,0,0.1);">
                    <div class="box-header">
                        <h3 class="box-title"><?php echo e(trans('areasTrans.AreaList')); ?> </h3>
                    </div>
                    <div class="box-body ">
                        <div class="form-row">
                            <div class="table-responsitve">
                                <table id="TableAreas" class="table table-dark table-bordered  table-striped ">
                                    <thead>
                                        <tr>
                                            
                                            <th><?php echo e(trans('areasTrans.AreaName')); ?></th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $governs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $govern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php $__currentLoopData = $govern->govern_areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    

                                                    <td> 
                                                        <?php if(App::islocale('ar')): ?>
                                                            <?php echo e($area->arname); ?>

                                                        <?php else: ?>
                                                            <?php echo e($area->name); ?>

                                                        <?php endif; ?>

                                                    </td>
                                                    <td style=" text-align: end" class="text-end">
                                                        
                                                        <button onclick="setModalAttr(this)"  type="button" id="EditBtn"
                                                            AreaUUID="<?php echo e($area->uuid); ?>"
                                                            AreaAr="<?php echo e($area->arname); ?>"AreaName="<?php echo e($area->name); ?>" governUUID="<?php echo e($govern->uuid); ?>" 
                                                            data-toggle="modal" data-target="#EditArea"
                                                            class="btn btn-success"><i class="fa fa-edit"></i></button>
                                                        <button type="button" class="btn btn-warning"><i
                                                                class="fa fa-eye"></i></button>
                                                        <button type="button" data-toggle="modal" data-target="#DeleteArea"
                                                            class="btn btn-danger"><i class="fa fa-close"></i></button>
                                                        
                                                    </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->



            </div>
        </div>

        <div class="modal fade" id="DeleteArea" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">

                <form action="">

                    <div class="modal-content">
                        <div class="modal-header bg-danger">
                            <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e(trans('areasTrans.DeleteAreaTitle')); ?></h5>
                            <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-row">
                                <?php echo csrf_field(); ?>
                                <?php echo e(trans('areasTrans.DeleteAreaMessage')); ?>

                            </div>
                        </div>
                        <div style="text-align: end !important" class="modal-footer ">
                            <button type="submit" class="btn btn-success" role="submit"><i
                                    class="fa fa-check"></i></button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal"><i
                                    class="fa fa-close"></i></button>
                        </div>
                    </div>


                </form>

            </div>
        </div>
        

        <div class="modal fade" id="EditArea" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">

                <form action="">

                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-row">

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="datePolicy">Policy Date:</label>
                                        <div class="input-group select">
                                            <div class="input-group-addon">
                                                <i class="fa fa-building-o"></i>
                                            </div>
                                            
                                            <select class="form-control select2 " style="width: 100%;" name=""
                                                id="EditAreaSelect">
                                                <option value=""><?php echo e(trans('areasTrans.selectChoose')); ?></option>

                                                <?php $__currentLoopData = $governs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $govern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(App::islocale('ar')): ?>
                                                        <option value="<?php echo e($govern->uuid); ?>"><?php echo e($govern->arname); ?>

                                                        </option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($govern->uuid); ?>"><?php echo e($govern->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <label style="color: red">error:</label>

                                        <!-- /.input group -->
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="datePolicy">Policy Date:</label>

                                        <div class="input-group date">
                                            <div class="input-group-addon">
                                                <i class="">Ar</i>
                                            </div>
                                            <input type="text" id="AreaArName" class="form-control pull-right ">
                                        </div>
                                        <!-- /.input group -->
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="datePolicy">Policy Date:</label>

                                        <div class="input-group date">
                                            <div class="input-group-addon">
                                                <i class="">Ar</i>
                                            </div>
                                            <input type="text" id="AreaName" class="form-control pull-right ">
                                        </div>
                                        <!-- /.input group -->
                                    </div>
                                </div>



                            </div>
                        </div>
                        <div style="text-align: end !important" class="modal-footer ">
                            <button type="button" class="btn btn-danger" data-dismiss="modal"><i
                                    class="fa fa-close"></i></button>
                            <button type="submit" class="btn btn-success" role="submit"><i
                                    class="fa fa-check"></i></button>
                        </div>
                    </div>


                </form>

            </div>
        </div>

        <div class="modal fade" id="AddNewArea" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">

            <form action="">

                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-row">

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="datePolicy">Policy Date:</label>
                                    <div class="input-group select">
                                        <div class="input-group-addon">
                                            <i class="fa fa-building-o"></i>
                                        </div>
                                        
                                        <select class="form-control select2 " style="width: 100%;" name=""
                                            id="">
                                            <option value=""><?php echo e(trans('areasTrans.selectChoose')); ?></option>

                                            <?php $__currentLoopData = $governs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $govern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(App::islocale('ar')): ?>
                                                    <option value="<?php echo e($govern->uuid); ?>"><?php echo e($govern->arname); ?>

                                                    </option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($govern->uuid); ?>"><?php echo e($govern->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <label style="color: red">error:</label>

                                    <!-- /.input group -->
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="datePolicy">Policy Date:</label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="">Ar</i>
                                        </div>
                                        <input type="text" id="AddAreaArName" class="form-control pull-right ">
                                    </div>
                                    <!-- /.input group -->
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="datePolicy">Policy Date:</label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="">Ar</i>
                                        </div>
                                        <input type="text" id="AddAreaName" class="form-control pull-right ">
                                    </div>
                                    <!-- /.input group -->
                                </div>
                            </div>



                        </div>
                    </div>
                    <div style="text-align: end !important" class="modal-footer ">
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i
                                class="fa fa-close"></i></button>
                        <button type="submit" class="btn btn-success" role="submit"><i
                                class="fa fa-check"></i></button>
                    </div>
                </div>


            </form>

        </div>
    </div>


    <?php $__env->stopSection(); ?>



    <?php $__env->startSection('scriptes'); ?>
        <script src=" <?php echo e(asset('plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
        <script>
            //Date picker

            $(document).ready(function() {

                $("#TableAreas").dataTable({});
                $(".select2").select2();


            
            });


            function setModalAttr (param) { 
               
                    $("#AreaName").val($(param).attr('AreaName'));
                    $("#AreaArName").val($(param).attr('AreaAr'));
                    // $("#EditAreaSelect").val($(param).attr('governUUID'))
             }
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('cpanel.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ERPI\resources\views/cpanel/pages/areas.blade.php ENDPATH**/ ?>