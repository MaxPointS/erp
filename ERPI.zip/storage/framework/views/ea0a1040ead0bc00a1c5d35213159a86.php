
<?php $__env->startSection('CatProducts'); ?>
    <?php
    use App\Models\areas;
    ?>

    <!---->
    <!--   <div class="page-title header-mt-10 rest-cover" style="background-image: url(http://www.tofialmeshaal.com/images/backbg/1.jpeg)">-->





    <!--    <div class="container">-->
    <!--        <div class="row rest-status">-->
    <!--            <div class="col-lg-12 text-left text-lg mb-3">-->


    <!--                <?php if(date('H:i') <= date('H:i', strtotime(session()->get('CloseTo')))): ?>
    -->
    <!--                <b class="badge badge-success">-->
    <!--                <?php echo e(trans('frontHeader.StateOpenTime')); ?> -->
    <!--                </b>-->
<!--                <?php else: ?>-->
    <!--                <b class="badge badge-danger">-->
    <!--                <?php echo e(trans('frontHeader.StateCloseTime')); ?>-->
    <!--            </b> -->
    <!--
    <?php endif; ?>-->

    <!--            </div>-->
    <!--            <div class="col-lg-12 text-left text-lg text-white">-->
    <!--                <h4 class="mb-0 txt-color">-->
    <!--                   <span class=""><?php echo e(trans('frontHeader.DeliverTime')); ?> &colon;</span> <span class=""> <?php if(date('A', strtotime(session()->get('OpenFrom'))) == 'AM'): ?>
    <?php echo e(date('h:i', strtotime(session()->get('OpenFrom')))); ?><?php echo e(trans('frontHeader.Morning')); ?>

    <?php endif; ?>
    </span>
    &ndash; <span class="">
    <?php if(date('A', strtotime(session()->get('CloseTo'))) == 'PM'): ?>
    <?php echo e(date('h:i', strtotime(session()->get('CloseTo')))); ?><?php echo e(trans('frontHeader.evening')); ?>

    <?php endif; ?>
    </span>-->
    <!--                    <br>-->
    <!--                    <?php echo e(trans('frontHeader.MinPriceOrder')); ?> &colon; <?php echo e(session()->get('MinOrderPrice')); ?>  <?php echo e(trans('frontHeader.KD')); ?>-->
    <!--                    </h4>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->



    <div class="page-title header-mt-10 rest-cover zooming mySlides"
        style="background-image: url(http://localhost:81/sweets-shop/public/images/backg.jpeg);height:300px">
        <h1></h1>
        <!--<div class="container">-->
        <!--    <div class="row rest-status">-->
        <!--        <div class="col-lg-12 text-left text-lg mb-3">-->

        <!--         <h1></h1>-->

        <!--            <?php if(date('H:i') <= date('H:i', strtotime(session()->get('CloseTo')))): ?>
    -->
        <!--            <b class="badge badge-success">-->
        <!--            <?php echo e(trans('frontHeader.StateOpenTime')); ?> -->
        <!--            </b>-->
    <!--            <?php else: ?>-->
        <!--            <b class="badge badge-danger">-->
        <!--            <?php echo e(trans('frontHeader.StateCloseTime')); ?> -->
        <!--        </b> -->
        <!--
    <?php endif; ?>-->

        <!--        </div>-->
        <!--        <div class="col-lg-12 text-left text-lg text-white">-->
        <!--            <h4 class="mb-0 txt-color">-->
        <!--               <span class=""><?php echo e(trans('frontHeader.DeliverTime')); ?> &colon;</span> <span class=""> <?php if(date('A', strtotime(session()->get('OpenFrom'))) == 'AM'): ?>
    <?php echo e(date('h:i', strtotime(session()->get('OpenFrom')))); ?><?php echo e(trans('frontHeader.Morning')); ?>

    <?php endif; ?>
    </span> &ndash; <span class="">
    <?php if(date('A', strtotime(session()->get('CloseTo'))) == 'PM'): ?>
    <?php echo e(date('h:i', strtotime(session()->get('CloseTo')))); ?><?php echo e(trans('frontHeader.evening')); ?>

    <?php endif; ?>
    </span>-->
        <!--                <br>-->
        <!--                <?php echo e(trans('frontHeader.MinPriceOrder')); ?> &colon; <?php echo e(session()->get('MinOrderPrice')); ?>  <?php echo e(trans('frontHeader.KD')); ?>-->
        <!--                </h4>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->
    </div>


    <style>
        #select2-area-vm-container,
        .select2-selection__rendered {
            color: black !important;
        }
    </style>

    <section class="section bg-light">
        <div class="container">
            <form id="checkout-form" action="<?php echo e(url('CheckOut')); ?>" name="checkoutdata" method="POST" data-validate=""
                novalidate="novalidate">
                <?php echo csrf_field(); ?>

 
                <div class="row">

                    <div class="<?php if(App::islocale('ar')): ?> col-xl-4 pull-xl-8 col-lg-5 pull-lg-7 <?php else: ?> col-xl-4 push-xl-8 col-lg-5 push-lg-7 <?php endif; ?> ">
                        <div class="shadow bg-white stick-to-content mb-4">
                            <div class="bg-dark dark p-4">
                                <h5 class="mb-0"><?php echo e(trans('frontHeader.YrOrder')); ?></h5>
                            </div>
                            <div class="panel-cart-content">
                                <table class="table-cart">
                                    <tbody>
                                        <?php $sum = 0; ?>
                                        <?php if($cart->count()>0): ?>
                                            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $sum += $item['TotalPrice']; ?>
                                                <tr>
                                                    <td class="cart-qty">
                                                        <div class="row text-md">
                                                            <span onclick="RemoveQtyFromCart(this)"
                                                                productid="<?php echo e($item->uuid); ?>"
                                                                productqty="<?php echo e($item->qty); ?>"
                                                                productPrice="<?php echo e($item->totalprice); ?>"
                                                                producttotalprice="<?php echo e($item['TotalPrice']); ?>"
                                                                class="remove_item order-qty-btn sub-qty"><i
                                                                    class="fa fa-minus-circle"></i></span>
                                                            &nbsp;&nbsp;
                                                            <strong class="order-item-qty"
                                                                id="Qty_Pro_<?php echo e($item->uuid); ?>"><?php echo e($item->qty); ?></strong>
                                                            &nbsp;&nbsp;
                                                            <span onclick="AddQtyToCart(this)"
                                                                productid="<?php echo e($item->uuid); ?>"
                                                                productqty="<?php echo e($item->qty); ?>"
                                                                productPrice="<?php echo e($item->totalprice); ?>"
                                                                producttotalprice="<?php echo e($item['TotalPrice']); ?>"
                                                                class="remove_item order-qty-btn add-qty"><i
                                                                    class="fa fa-plus-circle"></i></span>
                                                        </div>
                                                    </td>
                                                    <td class="title">
                                                        <span class="name"><a
                                                                href="#"><?php echo e($item['ProductName']); ?></a></span>
                                                    </td>
                                                    <td class="price">
                                                        <span
                                                            id="TotalPrice_Pro_<?php echo e($item->uuid); ?>"><?php echo e(number_format((float) $item['TotalPrice'], 3)); ?>

                                                        </span>
                                                    </td>
                                                    <td class="actions">
                                                        <a href="#" onclick="DeleteFromCart(this)"
                                                            productid="<?php echo e($item->uuid); ?>"
                                                            productqty="<?php echo e($item->qty); ?>"
                                                            productPrice="<?php echo e($item->totalprice); ?>"
                                                            producttotalprice="<?php echo e($item['TotalPrice']); ?>"
                                                            class="action-icon btn-remove text-danger" data-checkout="yes"
                                                            value="09fe876453489db0ab4f7ba73fcc0f6d"><i
                                                                class="ti ti-close"></i></a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                    </tbody>
                                </table>

                                <div class="cart-summary">
                                    <div class="row">
                                        <div class="col-7 text-right text-muted"><?php echo e(trans('frontHeader.Amount') . ' :'); ?>

                                        </div>
                                        <div class="col-5"><strong id="cartsubTotal">
                                                <?php echo e(number_format((float) $sum, 3)); ?></strong></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-7 text-right text-muted"><?php echo e(trans('frontHeader.delvCost') . ' :'); ?>

                                        </div>
                                        <div class="col-5"><strong
                                                id="cartDelv"><?php echo e(session()->get('DelvCost')); ?></strong></div>
                                    </div>
                                    <hr class="hr-sm">
                                    <div class="row text-lg">
                                        <div class="col-7 text-right text-muted"><?php echo e(trans('frontHeader.TotalPrice') . ' :'); ?>

                                        </div>
                                        <div class="col-5"><strong id="cart_total">
                                                <?php echo e(number_format((float) $sum + floatval(session()->get('DelvCost')), 3)); ?></strong>
                                        </div>
                                    </div>
                                    <hr class="mb-3">
                                    <div class="row ">
                                        <!-- <div class="col-12">General Note</div> -->
                                        <div class="col-12">
                                            <textarea cols="30" name="Commets" id="modal-comment-textarea" rows="2" class="form-control"
                                                placeholder="<?php echo e(trans('frontHeader.Comments') . '(' . trans('frontHeader.optionalField') . ')'); ?>"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div
                        class="<?php if(App::islocale('ar')): ?> col-xl-8 push-xl-4 col-lg-7 push-lg-5 checkout-fields <?php else: ?> col-xl-8 pull-xl-4 col-lg-7 pull-lg-5 checkout-fields <?php endif; ?> ">
                        
                        <?php if(session()->has('orderEror')): ?>
                            <div>
                                <h4 class="text-danger">


                                    <?php echo e(trans('frontHeader.errorMessage')); ?> &colon; <?php echo e(session()->get('MinOrderPrice')); ?>

                                    <?php echo e(trans('frontHeader.KD')); ?>



                                </h4>
                            </div>
                        <?php endif; ?>

                        <div class="bg-white p-4 p-md-5 mb-4">

                            <h4 class="border-bottom pb-4"><i
                                    class="ti ti-user ml-3 text-primary"></i><?php echo e(trans('frontHeader.MainData')); ?></h4>
                            <div class="row mb-5 ">
                                <div class="form-group col-sm-6">
                                    <label><?php echo e(trans('frontHeader.CustName') . ':'); ?></label>
                                    <input id="guest_name" required="" name="Customer_Name" class="form-control"
                                        aria-required="true">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label><?php echo e(trans('frontHeader.Mobile') . ':'); ?></label>
                                    <input type="number" maxlength="8" minlength="8" id="guest_contact"
                                        required=""  name="Customer_Mob" class="form-control" aria-required="true">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label><?php echo e(trans('frontHeader.H_tel') . ':'); ?></label>
                                    <input type="number" maxlength="8" minlength="8" id="guest_contact"
                                        name="Customer_Tel" class="form-control" aria-required="true">
                                </div>
                            </div>

                            <div id="address_block">
                                <h4 class="border-bottom pb-4"><i
                                        class="ti ti-map-alt ml-3 text-primary"></i><?php echo e(trans('frontHeader.address')); ?>

                                </h4>
                                <div class="row mb-5">
                                    <div class="form-group col-sm-12">
                                        <div class="select-container">
                                            <select name="AreaID" class="form-control select2" style="width:100%;">
                                                <option value=""><?php echo e(trans('frontHeader.ChooseArea')); ?></option>
                                                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(APP::islocale('ar')): ?>
                                                        <option <?php if(session()->get('AreaID') == $area->uuid): ?> selected <?php endif; ?>
                                                            value="<?php echo e($area->AreaID); ?>"><?php echo e($area->arname); ?></option>
                                                    <?php else: ?>
                                                        <option <?php if(session()->get('AreaID') == $area->uuid): ?> selected <?php endif; ?>
                                                            value="<?php echo e($area->AreaID); ?>"><?php echo e($area->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>

                                        </div>

                                    </div>

                                    <div class="form-group col-sm-6">
                                        <label></label>
                                        <input type="text" required="" 
                                            placeholder="<?php echo e(trans('frontHeader.Block')); ?> *" name="block"  
                                            id="block" class="form-control" aria-required="true">
                                    </div>

                                    <div class="form-group col-sm-6">
                                        <label></label>
                                        <input type="text"  
                                            placeholder="<?php echo e(trans('frontHeader.Jadda') . '(' . trans('frontHeader.optionalField') . ')'); ?>"
                                            name="Jadda" id="avenue" class="form-control">
                                    </div>

                                    <div class="form-group col-sm-6">
                                        <label></label>
                                        <input type="text" required="" 
                                            placeholder=" <?php echo e(trans('frontHeader.Street')); ?>*" name="street"
                                            id="street" class="form-control" aria-required="true">
                                    </div>

                                    <div class="form-group col-sm-6">
                                        <label></label>
                                        <input type="text" required="" name="houseno" 
                                            placeholder="<?php echo e(trans('frontHeader.HouseNo')); ?> *" id="houseno"
                                            class="form-control" aria-required="true">
                                    </div>

                                    <div class="form-group col-sm-6">
                                        <label></label>
                                        <input type="text" 
                                            placeholder="<?php echo e(trans('frontHeader.Floor') . '(' . trans('frontHeader.optionalField') . ')'); ?>"
                                            name="floor" id="floor" class="form-control">
                                    </div>

                                    <div class="form-group col-sm-6">
                                        <label></label>
                                        <input type="text" name="officeno_Dept" 
                                            placeholder="<?php echo e(trans('frontHeader.Dept') . '(' . trans('frontHeader.optionalField') . ')'); ?>"
                                            class="form-control">
                                    </div>

                                    


                                </div>
                            </div>

                            

                            <h4 class="border-bottom pb-4"><i
                                    class="ti ti-package ml-3 text-primary"></i><?php echo e(trans('frontHeader.OrderType')); ?></h4>
                            <div class="row mb-5 text-lg">
                                <div class="col-md-6 col-sm-6 form-group">
                                    <label class="custom-control custom-radio">
                                        <input type="radio" checked="" id="standard_time" name="order_time"
                                            value="0" class="custom-control-input">
                                        <span class="custom-control-indicator"><svg class="icon" x="0px"
                                                y="0px" viewBox="0 0 32 32">
                                                <path stroke-dasharray="19.79 19.79" stroke-dashoffset="19.79"
                                                    fill="none" stroke="#FFFFFF" stroke-width="4"
                                                    stroke-linecap="square" stroke-miterlimit="10"
                                                    d="M9,17l3.9,3.9c0.1,0.1,0.2,0.1,0.3,0L23,11"></path>
                                            </svg></span>
                                        <span class="custom-control-description">
                                            <?php echo e(trans('frontHeader.ordertimeMain')); ?><br>
                                            <small class="text-sm text-muted"><?php echo e(trans('frontHeader.ondelv')); ?></small>
                                        </span>

                                    </label>
                                </div>
                                <div class="col-md-6 col-sm-6 form-group">
                                    <label class="custom-control custom-radio">
                                        <input type="radio" id="some_time" name="order_time" value="1"
                                            class="custom-control-input">
                                        <span class="custom-control-indicator"><svg class="icon" x="0px"
                                                y="0px" viewBox="0 0 32 32">
                                                <path stroke-dasharray="19.79 19.79" stroke-dashoffset="19.79"
                                                    fill="none" stroke="#FFFFFF" stroke-width="4"
                                                    stroke-linecap="square" stroke-miterlimit="10"
                                                    d="M9,17l3.9,3.9c0.1,0.1,0.2,0.1,0.3,0L23,11"></path>
                                            </svg></span>
                                        <span class="custom-control-description"><?php echo e(trans('frontHeader.orderlater')); ?><br>
                                            <span class="text-sm text-muted"><?php echo e(trans('frontHeader.choosetime')); ?></span>
                                        </span>

                                    </label>
                                </div>

                                <div id="choose_time" style="display:none"
                                    class=" <?php if(App::islocale('ar')): ?> form-group pull-md-6 col-sm-5 text-md <?php else: ?> form-group push-md-6 col-sm-5 text-md <?php endif; ?>">
                                    <label><?php echo e(trans('frontHeader.LaterMessage')); ?></label>
                                    <div class="form-group bootstrap-timepicker">
                                        <input id="expected_order_time" autocomplete="off" name="expected_order_time"
                                            class="form-control datetimepicker">
                                    </div>
                                </div>
                            </div>

                            <h4 class="border-bottom pb-4"><i
                                    class="ti ti-wallet ml-3 text-primary"></i><?php echo e(trans('frontHeader.Payment')); ?></h4>
                            <div class="row text-lg">
                                <div class="col-md-6 col-sm-6 form-group">
                                    <label class="custom-control custom-radio">
                                        <input type="radio" checked="" name="payment_method_id" value="1"
                                            class="custom-control-input">
                                        <span class="custom-control-indicator"><svg class="icon" x="0px"
                                                y="0px" viewBox="0 0 32 32">
                                                <path stroke-dasharray="19.79 19.79" stroke-dashoffset="19.79"
                                                    fill="none" stroke="#FFFFFF" stroke-width="4"
                                                    stroke-linecap="square" stroke-miterlimit="10"
                                                    d="M9,17l3.9,3.9c0.1,0.1,0.2,0.1,0.3,0L23,11"></path>
                                            </svg></span>
                                        <span class="custom-control-description"><?php echo e(trans('frontHeader.KNetPay')); ?></span>
                                    </label>
                                </div>
                                <div class="col-md-6 col-sm-6 form-group">
                                    <label class="custom-control custom-radio">
                                        <input type="radio" name="payment_method_id" value="2"
                                            class="custom-control-input">
                                        <span class="custom-control-indicator"><svg class="icon" x="0px"
                                                y="0px" viewBox="0 0 32 32">
                                                <path stroke-dasharray="19.79 19.79" stroke-dashoffset="19.79"
                                                    fill="none" stroke="#FFFFFF" stroke-width="4"
                                                    stroke-linecap="square" stroke-miterlimit="10"
                                                    d="M9,17l3.9,3.9c0.1,0.1,0.2,0.1,0.3,0L23,11"></path>
                                            </svg></span>
                                        <span
                                            class="custom-control-description"><?php echo e(trans('frontHeader.OnDelver')); ?></span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <!-- Modal / OTP -->
                        


                        <div class="text-center">
                            <button role="submit" class="btn btn-primary btn-lg"
                                id="order-now"><span><?php echo e(trans('frontHeader.OrderNow')); ?></span></button>
                        </div>

                    </div>





                </div>
            </form>

        </div>
    </section>
    <script>
        function RemoveQtyToCart(item) {

            let productid = $(item).attr('productid');
            let productQty = $(item).attr('productqty');
            let productTotal = $(item).attr('producttotalprice');
            let txtPricePro = $(item).attr('productPrice');
            let tokens = "<?php echo e(csrf_token()); ?>";
            let qtyTxt = $("#Qty_Pro_" + productid).text();
            let txtTotalPricePro = $("#TotalPrice_Pro_" + productid).text();
            let txtsubTotal = $("#cartsubTotal").text(); //
            let txtCartTotal = $("#cart_total").text(); //cart_total
            let txtDelvPrice = parseFloat($("#cartDelv").text()).toFixed(3);
            let delvCost = parseFloat($("#cartDelv").text()).toFixed(3);
            if (parseInt(qtyTxt) === 1) {
                return;
            } else {
                $("#Qty_Pro_" + productid).text(parseInt(qtyTxt) - 1);
                productQty = parseInt($("#Qty_Pro_" + productid).text());
            }
            txtTotalPricePro = parseFloat(parseFloat(txtPricePro).toFixed(3) * parseInt(productQty)).toFixed(3);
            $("#TotalPrice_Pro_" + productid).text(txtTotalPricePro);
            $("#cartsubTotal").text(parseFloat(parseFloat(txtsubTotal) - parseFloat(txtPricePro)).toFixed(3));
            $("#cart_total").text(parseFloat(parseFloat(txtsubTotal) - parseFloat(txtPricePro) + parseFloat(delvCost))
                .toFixed(3));

            $.ajax({
                type: "PUT",
                url: "<?php echo e(url('/CartOrders') . '/'); ?>" + productid,
                data: {
                    _token: tokens,
                    proid: productid,
                    proqty: productQty,
                    prototalprice: txtTotalPricePro
                },
                dataType: "json",
                success: function(response) {
                    console.log(response);
                },
                error: function(err) {
                    console.log(err);
                }
            });

        }

        function AddQtyToCart(item) {

            let productid = $(item).attr('productid');
            let productQty = $(item).attr('productqty');
            let productTotal = $(item).attr('producttotalprice');
            let txtPricePro = $(item).attr('productPrice');
            let tokens = "<?php echo e(csrf_token()); ?>";
            let qtyTxt = $("#Qty_Pro_" + productid).text();
            let txtTotalPricePro = $("#TotalPrice_Pro_" + productid).text();
            let txtsubTotal = $("#cartsubTotal").text(); //
            let txtCartTotal = $("#cart_total").text(); //
            let txtDelvPrice = parseFloat($("#cartDelv").text()).toFixed(3);
            let delvCost = parseFloat($("#cartDelv").text()).toFixed(3);
            if (parseInt(qtyTxt) < 1) {
                return;
            } else {
                $("#Qty_Pro_" + productid).text(parseInt(qtyTxt) + 1);
                productQty = parseInt($("#Qty_Pro_" + productid).text());

            }
            txtTotalPricePro = parseFloat(parseFloat(txtPricePro).toFixed(3) * parseInt(productQty)).toFixed(3);


            $("#TotalPrice_Pro_" + productid).text(txtTotalPricePro);
            $("#cartsubTotal").text(parseFloat(parseFloat($("#cartsubTotal").text()) + parseFloat(txtPricePro)).toFixed(3));
            $("#cart_total").text(parseFloat(parseFloat($("#cartsubTotal").text()) + parseFloat(delvCost)).toFixed(3));

            $.ajax({
                type: "PUT",
                url: "<?php echo e(url('/CartOrders') . '/'); ?>" + productid,
                data: {
                    _token: tokens,
                    proid: productid,
                    proqty: productQty,
                    prototalprice: txtTotalPricePro
                },
                dataType: "json",
                success: function(response) {
                    console.log(response);
                },
                error: function(err) {
                    console.log(err);
                }
            });

        }

        function DeleteFromCart(item) {
            let productid = $(item).attr('productid');
            let productQty = $(item).attr('productqty');
            let productTotal = $(item).attr('producttotalprice');
            let txtPricePro = $(item).attr('productPrice');
            let tokens = "<?php echo e(csrf_token()); ?>";
            let qtyTxt = $("#Qty_Pro_" + productid).text();
            let txtTotalPricePro = $("#TotalPrice_Pro_" + productid).text();
            let txtsubTotal = $("#cartsubTotal").text(); //
            let txtCartTotal = $("#cart_total").text(); //cart_total
            let txtDelvPrice = parseFloat($("#cartDelv").text()).toFixed(3);
            let delvCost = parseFloat($("#cartDelv").text()).toFixed(3);


            productQty = parseInt($("#Qty_Pro_" + productid).text());
            txtTotalPricePro = parseFloat(parseFloat(txtPricePro).toFixed(3) * parseInt(productQty)).toFixed(3);
            $("#TotalPrice_Pro_" + productid).text(txtTotalPricePro);

            $("#cartsubTotal").text(parseFloat(parseFloat(txtsubTotal) - parseFloat(txtTotalPricePro)).toFixed(3));

            $("#cart_total").text(parseFloat(parseFloat(txtsubTotal) - parseFloat(txtTotalPricePro) + parseFloat(delvCost))
                .toFixed(3));

            $.ajax({
                type: "DELETE",
                url: "<?php echo e(url('/CartOrders') . '/'); ?>" + productid,
                data: {
                    _token: tokens,
                    proid: productid,
                    proqty: productQty,
                    prototalprice: txtTotalPricePro
                },
                dataType: "json",
                success: function(response) {
                    $(item).parents("tr").remove();

                    $(".cart-count").text(parseInt(response.CartLenth));
                    if (parseInt(response.CartLenth) === 0) {
                        location.href = "./";
                    }

                   
                    //console.log(response);
                },
                error: function(err) {
                    console.log(err);
                }
            });



        }
    </script>

    <script>
        var slideIndex = 0;
        window.onload = function() {
            //setTimeout();
            setInterval(changeImage, 5000);

            var imgs //= document.getElementsByTagName("img");

            imgs = [
                'http://localhost:81/sweets-shop/public/images/backg.jpeg',
                'http://localhost:81/sweets-shop/public/images/Products/5fd8d05951ccc5fd8d05951ccf.jpeg',
                'http://localhost:81/sweets-shop/public/images/Products/5fd8d0e2048645fd8d0e204867.jpeg',
                'http://localhost:81/sweets-shop/public/images/Products/5fd8d1b06fca65fd8d1b06fca8.jpeg',
                'http://localhost:81/sweets-shop/public/images/Products/5fd8d6c7cf46f5fd8d6c7cf471.jpeg',
            ];
            var slides = document.getElementsByClassName("mySlides");
            // slides[0].style.backgroundImage  = "url('"+imgSrc()+"')";  

            function changeImage() {
                var i = Math.floor((Math.random() * 3));

                slides[0].style.backgroundImage = "url('" + imgs[i] + "')";

            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ERPI\resources\views/front/pages/cartOrders.blade.php ENDPATH**/ ?>