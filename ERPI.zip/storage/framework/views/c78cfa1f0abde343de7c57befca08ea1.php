

<?php $__env->startSection('content-header'); ?>
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <?php if(App::islocale('ar')): ?>
        <style>
            #ableAreas_filter,
            .dataTables_filter,
            .dataTables_paginate {
                float: left;
                text-align: end;
            }
        </style>
    <?php endif; ?>

    <style>
        .select2-selection {
            border-radius: 0 !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br />


    <div class="row ">
        <div class="col-md-12 ">
            <div class="box" style="border: 0 !important;box-shadow: 0 1px 9px 3px rgba(0,0,0,0.1);">
                <div class="box-header">
                    <h3 class="box-title"><?php echo e(trans('governTrans.CreategovernorateTitle')); ?> </h3>
                </div>
                <div class="box-body ">
                    <div class="form-row">

                        <div class="col-md-6">

                            <button data-toggle="modal" data-target="#AddNewArea" class="btn btn-success"><?php echo e(trans('governTrans.Creategovernorate')); ?> </button>
                        </div>



                    </div>

                </div>
                <!-- /.box -->



            </div>
        </div>
    </div>




        <div class="row ">
            <div class="col-md-12 ">
                <div class="box" style="border: 0 !important;box-shadow: 0 1px 9px 3px rgba(0,0,0,0.1);">
                    <div class="box-header">
                        <h3 class="box-title"><?php echo e(trans('governTrans.governorateList')); ?> </h3>
                    </div>
                    <div class="box-body ">
                        <div class="form-row">
                            <div class="table-responsitve">
                                <table id="TableAreas" class="table table-dark table-bordered  table-striped ">
                                    <thead>
                                        <tr>
                                            
                                            <th><?php echo e(trans('governTrans.governorateName')); ?></th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $servicesTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $govern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                             <td>
                                                <?php if(App::islocale('ar')): ?>
                                                    <?php echo e($govern->arname); ?>

                                                <?php else: ?>
                                                <?php echo e($govern->name); ?>

                                                    
                                                <?php endif; ?>

                                             </td>
                                             <td style=" text-align: end" class="text-end">
                                                
                                                <button onclick="setModalAttr(this)"  type="button" id="EditBtn"
                                                    
                                                    AreaAr="<?php echo e($govern->arname); ?>"AreaName="<?php echo e($govern->name); ?>" governUUID="<?php echo e($govern->uuid); ?>" 
                                                    data-toggle="modal" data-target="#EditArea"
                                                    class="btn btn-success"><i class="fa fa-edit"></i></button>
                                                
                                                <button type="button"  data-toggle="modal" data-target="#DeleteArea"
                                                    class="btn btn-danger"><i class="fa fa-close"></i></button>
                                                
                                            </td>
                                             </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->



            </div>
        </div>

        <div class="modal fade" id="DeleteArea" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">

                <form action="">

                    <div class="modal-content">
                        <div class="modal-header bg-danger">
                            <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e(trans('governTrans.DeletegovernorateTitle')); ?></h5>
                            <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-row">
                                <?php echo csrf_field(); ?>
                                <?php echo e(trans('governTrans.DeletegovernorateMessage')); ?>

                            </div>
                        </div>
                        <div style="text-align: end !important" class="modal-footer ">
                            <button type="submit" class="btn btn-success" role="submit"><i
                                    class="fa fa-check"></i></button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal"><i
                                    class="fa fa-close"></i></button>
                        </div>
                    </div>


                </form>

            </div>
        </div>
        

        <div class="modal fade" id="EditArea" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">

                <form action="">

                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-row">

                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="datePolicy">Policy Date:</label>

                                        <div class="input-group date">
                                            <div class="input-group-addon">
                                                <i class="">Ar</i>
                                            </div>
                                            <input type="text" id="AreaArName" class="form-control pull-right ">
                                        </div>
                                        <!-- /.input group -->
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="datePolicy">Policy Date:</label>

                                        <div class="input-group date">
                                            <div class="input-group-addon">
                                                <i class="">Ar</i>
                                            </div>
                                            <input type="text" id="AreaName" class="form-control pull-right ">
                                        </div>
                                        <!-- /.input group -->
                                    </div>
                                </div>



                            </div>
                        </div>
                        <div style="text-align: end !important" class="modal-footer ">
                            <button type="button" class="btn btn-danger" data-dismiss="modal"><i
                                    class="fa fa-close"></i></button>
                            <button type="submit" class="btn btn-success" role="submit"><i
                                    class="fa fa-check"></i></button>
                        </div>
                    </div>


                </form>

            </div>
        </div>

        <div class="modal fade" id="AddNewArea" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">

            <form action="">

                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-row">

                           
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="datePolicy">Policy Date:</label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="">Ar</i>
                                        </div>
                                        <input type="text" id="AddAreaArName" class="form-control pull-right ">
                                    </div>
                                    <!-- /.input group -->
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="datePolicy">Policy Date:</label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="">Ar</i>
                                        </div>
                                        <input type="text" id="AddAreaName" class="form-control pull-right ">
                                    </div>
                                    <!-- /.input group -->
                                </div>
                            </div>



                        </div>
                    </div>
                    <div style="text-align: end !important" class="modal-footer ">
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i
                                class="fa fa-close"></i></button>
                        <button type="submit" class="btn btn-success" role="submit"><i
                                class="fa fa-check"></i></button>
                    </div>
                </div>


            </form>

        </div>
    </div>


    <?php $__env->stopSection(); ?>



    <?php $__env->startSection('scriptes'); ?>
        <script src=" <?php echo e(asset('plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
        <script>
            //Date picker

            $(document).ready(function() {

                $("#TableAreas").dataTable({});
                $(".select2").select2();


            
            });


            function setModalAttr (param) { 
               
                    $("#AreaName").val($(param).attr('AreaName'));
                    $("#AreaArName").val($(param).attr('AreaAr'));
                    // $("#EditAreaSelect").val($(param).attr('governUUID'))
             }
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('cpanel.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ERPI\resources\views/cpanel/pages/companiesservicestypes.blade.php ENDPATH**/ ?>