<!-- Header -->
<header id="header" class="light fixed">

    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <!-- Logo -->
                <div class="module module-logo transparent">
                    <a href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('images/logo2.png')); ?>" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-7">
                <!-- Navigation -->
                <nav class="module module-navigation  ml-4">
                    <ul <?php if(App::islocale('ar')): ?> dir="rtl" <?php endif; ?> id="nav-main" class="nav nav-main">
                        <li><a class="about-us-li" href="<?php echo e(route('home')); ?>"><i class="ti ti-home"></i>
                                <?php echo e(trans('frontHeader.MainPage')); ?> </a></li>
                        <?php if(App::islocale('en')): ?>
                            <li>
                                <form id="changeLangForm" method="POST" action="<?php echo e(route('ChangeLangauge')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="lang" value="ar">
                                    <a href="" id="submitFormLink" style="cursor: pointer;"><i
                                            class="ti ti-world"></i> ARABIC</a>
                                </form>
                            </li>
                        <?php else: ?>
                            
                            
                            <li>
                                <form id="changeLangForm" method="POST" action="<?php echo e(route('ChangeLangauge')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="lang" value="en">
                                    <a href="" id="submitFormLink" style="cursor: pointer;"><i
                                            class="ti ti-world"></i> English</a>
                                </form>
                            </li>
                        <?php endif; ?>

                        <li><a class="about-us-li" href="<?php echo e(url('about')); ?>"><i class="ti ti-view-grid"></i>
                                <?php echo e(trans('frontHeader.About')); ?> </a></li>
                        <li><a href=""><i class="ti ti-truck"></i>
                                <?php echo e(trans('frontHeader.followorder')); ?> </a></li>


                        
                    </ul>
                </nav>
            </div>
            <div class="col-md-2">
                
                <a href="#" class="module module-cart left" data-toggle="panel-cart">
                    <span class="cart-icon">
                        <i class="ti ti-shopping-cart"></i>
                        <span id="cart-count" class="notification cart-count">

                            <?php if($cart->count() > 0): ?>
                                <?php echo e($cart->count()); ?>

                            <?php else: ?>
                                0
                            <?php endif; ?>
                        </span>
                    </span>

                    <span id="cart-value" class="cart-value">
                        <?php if($cart->count() > 0): ?>
                            <?php
                                $totalcartPrice = 0.0;

                                if ($cart->count() > 0) {
                                    foreach ($cart as $item) {
                                        $totalcartPrice += round($item->qty * $item->services->first()->price, 3);
                                    };
                                }
                            ?>
                            <?php echo e($totalcartPrice); ?>

                       
                        <?php else: ?>
                            0.000
                        <?php endif; ?>
                    </span>
                </a>
            </div>
        </div>
    </div>

</header>
<!-- Header / End -->

<!-- Header -->
<header id="header-mobile" class="light">

    <div class="module module-nav-toggle">
        <a href="#" id="nav-toggle"
            data-toggle="panel-mobile"><span></span><span></span><span></span><span></span></a>
    </div>

    <div class="module module-logo">
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('images/logo2.png')); ?>" alt="">
        </a>
    </div>
    
    
    


    <div class="">
        <a href="#" class="module module-cart left" data-toggle="panel-cart">
            <span class="cart-icon">
                <i class="ti ti-shopping-cart"></i>
                <span class="notification cart-count">
                    <?php if($cart->count() > 0): ?>
                                <?php echo e($cart->count()); ?>

                            <?php else: ?>
                                0
                            <?php endif; ?>
                </span>
            </span>
            
        </a>
    </div>

</header>
<?php /**PATH C:\xampp\htdocs\ERPI\resources\views/front/inc/header.blade.php ENDPATH**/ ?>