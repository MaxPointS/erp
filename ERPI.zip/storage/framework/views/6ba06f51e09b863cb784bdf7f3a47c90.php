<?php $__env->startSection('css'); ?>
    <style>
        .select2-selection {
            border-radius: 0 !important;
        }
    </style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('storeCompany')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row ">
            <div class="col-md-12 ">
                <div class="box" style="border: 0 !important;box-shadow: 0 1px 9px 3px rgba(0,0,0,0.1);">
                    <div class="box-header">
                        <h3 class="box-title"><?php echo e(trans('companyTrans.CreateTitle')); ?> </h3>
                    </div>
                    <div class="box-body ">

                        <div class="form-row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="arname"><?php echo e(trans('companyTrans.arname')); ?></label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="">Ar</i>
                                        </div>
                                        <input   type="text" id="arname" name="arname" value="<?php echo e(old('arname')); ?>"
                                            class="form-control pull-right datepicker">
                                    </div>
                                    <label for="arname" style="color: red">
                                    <?php $__errorArgs = ['arname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                    <!-- /.input group -->
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name"><?php echo e(trans('companyTrans.name')); ?></label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="">En</i>
                                        </div>
                                        <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>"
                                            class="form-control pull-right datepicker">
                                    </div>
                                    <label for="address" style="color: red" class="name">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                    <!-- /.input group -->
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="address"><?php echo e(trans('companyTrans.address')); ?></label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-home"></i>
                                        </div>
                                        <input type="text" name="address" id="address" value="<?php echo e(old('address')); ?>"
                                            class="form-control pull-right ">
                                    </div>
                                    <label for="address" style="color: red">
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                    <!-- /.input group -->
                                </div>
                            </div>


                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="araddress"><?php echo e(trans('companyTrans.araddress')); ?></label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-home"></i>
                                        </div>
                                        <input type="text" name="araddress" id="araddress" value="<?php echo e(old('araddress')); ?>"
                                            class="form-control pull-right ">
                                    </div>
                                    <label for="araddress" style="color: red">
                                        <?php $__errorArgs = ['araddress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                    <!-- /.input group -->
                                </div>
                            </div>


                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="companyServiceType"><?php echo e(trans('companyTrans.servicetype')); ?></label>

                                    <div class="input-group text">
                                        <div class="input-group-addon">
                                            <i class="fa fa-building-o"></i>
                                        </div>
                                        
                                        <select class="form-control select2 " style="width: 100%"
                                            style="border-radius:0 !important; " name="companyServiceType"
                                            id="companyServiceType">
                                            <option value=""><?php echo e(trans('companyTrans.choose')); ?></option>
                                            <?php $__currentLoopData = $companyservicetype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(App::islocale('ar')): ?>
                                                    <option value="<?php echo e($serviceType->uuid); ?>"><?php echo e($serviceType->arname); ?>

                                                    </option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($serviceType->uuid); ?>"><?php echo e($serviceType->name); ?>

                                                    </option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <label style="color: red">
                                        <?php $__errorArgs = ['companyServiceType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                    <!-- /.input group -->
                                </div>
                            </div>


                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="location"><?php echo e(trans('companyTrans.location')); ?></label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-link"></i>
                                        </div>
                                        <input type="text" name="location" id="location" value="<?php echo e(old('location')); ?>"
                                            class="form-control pull-right ">
                                    </div>
                                    <!-- /.input group -->
                                    <label style="color: red" for="location">
                                        <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </label>
                                </div>
                            </div>


                            <div class="col-md-4">
                                <div class="form-group">
                                    <label><?php echo e(trans('companyTrans.status')); ?></label>
                                    <div class="form-group  is-invalid">

                                        <div class="is-invalid">
                                            <label>
                                                <input checked name="status" type="checkbox" class="form-control is-invalid" data-toggle="toggle"
                                                    data-style="slow">
                                            </label>
                                        </div>
                                    </div>
                                    <!-- /.input group -->
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="tel"><?php echo e(trans('companyTrans.tel')); ?></label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-phone"></i>
                                        </div>
                                        <input type="number" min="0" minlength="8" maxlength="8" value="<?php echo e(old('tel')); ?>"
                                            placeholder="+96500000000" max="+99999999999" name="tel" id="tel"
                                            class="form-control  ">
                                        
                                    </div>
                                    <!-- /.input group -->
                                    <label style="color: red">
                                        <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="image"><?php echo e(trans('companyTrans.image')); ?></label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-image"></i>
                                        </div>
                                        <input type="file" name="image" accept="image/*" id="image"
                                            class="form-control pull-right ">
                                    </div>
                                    <!-- /.input group -->
                                    <label style="color: red"><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>

                                </div>
                            </div>






                        </div>


                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <button class="btn btn-success pull-right">filter</button>
                    </div>
                </div>
                <!-- /.box -->



            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scriptes'); ?>
    <script>
        $(".select2").select2();
        $("#tel").keydown(function(e) {

        });
        // const Toast = Swal.mixin({
        //     toast: true,
        //     position: 'top-end',
        //     showConfirmButton: false,
        //     timer: 3000,
        //     timerProgressBar: true,
        //     didOpen: (toast) => {
        //         toast.addEventListener('mouseenter', x.play())
        //         // toast.addEventListener('mouseleave', Swal.resumeTimer)
        //     }
        // });
        // Toast.fire({
        //     icon: 'success',
        //     title: '<?php echo e(trans('companyTrans.choose')); ?>',
        //     background: "green",
        // });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cpanel.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ERPI\resources\views/cpanel/pages/CreateCompany.blade.php ENDPATH**/ ?>