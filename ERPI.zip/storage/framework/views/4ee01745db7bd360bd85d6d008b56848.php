
<?php $__env->startSection('CatProducts'); ?>
    <!--<div class="page-title header-mt-10 bg-dark dark">
                -->
    <!-- BG Image -->
    <!--    <div class="bg-image bg-parallax skrollable skrollable-between" data-top-bottom="background-position-y: 30%" data-bottom-top="background-position-y: 70%" style="background-image: url(&quot;http://alkadisweets.com/assets/img/photos/bg-croissant.jpg&quot;); background-position-y: 37.0677%;"><img src="http://alkadisweets.com/assets/img/photos/bg-croissant.jpg" alt="" style="display: none;"></div>-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-lg-8 push-lg-4">-->

    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->





    <div class="page-title header-mt-10 rest-cover zooming mySlides"
        style="background-image: url(<?php echo e(asset('images/back.jpeg')); ?>);height:300px">
        <h1></h1>


    </div>



    <section class="section bg-light">

        <div class="container">

            <div class="row">

                
                <div class="col-12">

                    <div class="bg-white p-4 p-md-5 mb-4 ">
                        <h4 class="border-bottom pb-4"><i
                                class="fa fa-book  fa-x ml-3 text-success"></i><?php echo e(trans('frontHeader.aboutCom')); ?></h4>

                        



                        About the company: Amnaha Insurance Brokerage Company is an insurance brokerage company that works
                        in providing professional advice and assistance to clients to protect them, their property, and
                        their employees according to highly professional and effective principles. Since the beginning of
                        its establishment in 2016, Amnaha Insurance Brokerage Company has been striving to excel in the
                        insurance market by providing all insurance solutions for companies and individuals through its
                        network of branches spread throughout various regions of Kuwait and a team of trained employees who
                        compete in providing advisory services to find the best insurance services. Our role as a broker is
                        In carrying out the task of mediation with complete independence between clients and insurance
                        companies, advising clients on which insurance companies are best suited to meet their needs and
                        establishing a long-term relationship based on mutual benefit, this involves making regular visits
                        to the client to understand the nature of his business and his insurance needs and requirements. It
                        also includes monitoring any changes in the client’s circumstances, and adjusting the insurance
                        coverage accordingly. We also pay great attention to interpreting the meanings and terms of the
                        documents, and clarifying any points, no matter how small. Then we arrange and present our
                        suggestions to the best insurance company according to coverage, premiums, management and speed of
                        claims settlement
                        <div class="text-center">
                            <a href="<?php echo e(url('/')); ?>" class="btn btn-lg" style="color:#824072 !important"
                                id="order-now"><span><i class="fa fa-home"></i>&nbsp;
                                    <?php echo e(trans('frontHeader.back')); ?></span></a>
                        </div>

                    </div>


                </div>
            </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ERPI\resources\views/front/pages/about.blade.php ENDPATH**/ ?>