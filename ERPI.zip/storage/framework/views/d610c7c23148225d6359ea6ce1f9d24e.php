<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="noarchive">
    <meta name="keywords" content="" />
    <meta name="description" content="" />

    <!-- Title -->
    <title><?php echo e(trans('frontHeader.SiteVendor')); ?></title>


    


    <!-- CSS Plugins -->
    <?php echo $__env->make('front.inc..frontCSS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('css'); ?>

    <!-- CSS Theme -->
    <style>
        #panel-cart .panel-cart-action {
            background-color: #ffffff;
            padding: 1rem 0;
        }
    </style>


</head>

<body>

    <div id="body-wrapper" <?php if(App::islocale('ar')): ?> dir="rtl" <?php endif; ?> class="animsition">


        <?php echo $__env->make('front.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        

        <?php echo $__env->yieldContent('services'); ?>


        <?php echo $__env->make('front.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        
    </div>



    <?php echo $__env->make('front.inc.frontScripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent("scripts"); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ERPI\resources\views/front/layout/master.blade.php ENDPATH**/ ?>