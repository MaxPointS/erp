<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <ul class="sidebar-menu">

            <li class="">
                <a href="<?php echo e(route('dashboard')); ?>">
                    <i class="fa fa-dashboard"></i><span><?php echo e(trans('nav.Dashboard')); ?></span>
                </a>

            </li>


            <li class="treeview">
                <a href="<?php echo e(route('com-service-view')); ?>">
                    <i class="fa fa-files-o"></i>
                    <span><?php echo e(trans('nav.Pranch')); ?></span>
                    <span class="label label-primary pull-right"></span>
                </a>
            </li>


            <li class="treeview">
                <a href="#">
                    <i class="fa fa-pie-chart"></i>
                    <span><?php echo e(trans('nav.vehicles')); ?></span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(route('showInsuranceViechle')); ?>"><i
                                class="fa fa-circle-o"></i><?php echo e(trans('nav.vehiclesInsuredList')); ?></a></li>

                    

                </ul>
            </li>

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-pie-chart"></i>
                    <span><?php echo e(trans('nav.Companies')); ?></span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(route('showCompaniesList')); ?>"><i
                                class="fa fa-circle-o"></i><?php echo e(trans('nav.Companiesdashboard')); ?></a></li>

                    <li><a href="<?php echo e(route('CreateCompany')); ?>"><i
                                class="fa fa-circle-o"></i><?php echo e(trans('nav.companiesList')); ?></a></li>

                    <li><a href="<?php echo e(route('AddService')); ?>"><i
                                class="fa fa-circle-o"></i><?php echo e(trans('nav.addservice')); ?></a></li>

                </ul>
            </li>

            

            

            


            
            


            <li class="treeview">
                <a href="#">
                    <i class="fa fa-gear"></i> <span><?php echo e(trans('nav.Settings')); ?></span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>

                <ul class="treeview-menu">
                    
                    <li>
                        <a href="<?php echo e(route('areas')); ?>"><i class="fa fa-circle-o"></i><?php echo e(trans('nav.Areas')); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('governs')); ?>"><i class="fa fa-circle-o"></i><?php echo e(trans('nav.governs')); ?></a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('serviceType')); ?>"><i class="fa fa-circle-o"></i><?php echo e(trans('nav.serviceType')); ?></a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('RoleList')); ?>"><i
                                class="fa fa-circle-o"></i><?php echo e(trans('nav.role')); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('UsersList')); ?>"><i
                                class="fa fa-circle-o"></i><?php echo e(trans('nav.UsersMenu')); ?></a>
                    </li>


                </ul>
            </li>



        </ul>

    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\xampp\htdocs\ERPI\resources\views/cpanel/inc/SideBar.blade.php ENDPATH**/ ?>